function App(){

    //Declare your instance variables here.
    this.
    this.
    this.

    //Declare the instance function open here.
    this.open = function(){



    };
    //Declare the instance function sleep here.



    //Declare the instance function active here.



    //Declare the instance function close here.




}

//Use the constructor to create 4 App objects below.



//Declare an array named appList, and place all 4 of your apps in that array.
//The order does not matter.
